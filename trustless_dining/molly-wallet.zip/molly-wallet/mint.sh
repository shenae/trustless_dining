#!/bin/bash
./node_modules/clevis/bin.js contract mintNextTokenWithTokenURI Badges 0 $2 https://badges.xdai.io/ethdenver/v1/json/$1.json
