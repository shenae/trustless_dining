#!/bin/bash
#npm run build &&
./node_modules/clevis/bin.js upload rim.xdai.io
./node_modules/clevis/bin.js invalidate E1WI4O2ZFUN8H0
