#!/bin/bash
#npm run build &&
./node_modules/clevis/bin.js upload fairtags.xdai.io && ./node_modules/clevis/bin.js invalidate ETOJ2KIKRPHE8
