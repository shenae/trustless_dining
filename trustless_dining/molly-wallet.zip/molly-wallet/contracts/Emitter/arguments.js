/*
  Example of passing in a string to the constructor:
  module.exports = ["hello world"]
*/

module.exports = []
