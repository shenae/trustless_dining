#!/bin/bash
#npm run build &&
./node_modules/clevis/bin.js invalidate E1H2IR2NY2NQDL
