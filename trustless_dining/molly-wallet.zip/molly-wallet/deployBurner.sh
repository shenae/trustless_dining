#!/bin/bash
#npm run build &&
./node_modules/clevis/bin.js upload burnerwallet.io && ./node_modules/clevis/bin.js invalidate EO4J1L211YU2O
