#!/bin/bash
#move compiled files and production address to relay at:
#cryptogs box at:
#/home/ubuntu/burner-wallet/src/contracts
scp src/contracts/* cryptogs:/home/ubuntu/burner-wallet/src/contracts/
