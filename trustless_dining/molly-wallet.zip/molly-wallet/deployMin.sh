#!/bin/bash
#npm run build &&
./node_modules/clevis/bin.js upload min.xdai.io
./node_modules/clevis/bin.js invalidate E23WC08CRBEWSW
