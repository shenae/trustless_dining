#!/bin/bash
docker stop clevis
