#!/bin/bash
#npm run build &&
./node_modules/clevis/bin.js invalidate E3UXHQH85ACKYA
