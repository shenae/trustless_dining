#!/bin/bash
./mint.sh buffalo $1
./mint.sh Rhino $1
./mint.sh Zebra $1
./mint.sh Fish $1
./mint.sh Hippo $1
./mint.sh Walrus $1
./mint.sh MountainGoat $1
./mint.sh Elephant $1
./mint.sh Lobster $1
./mint.sh Octopus $1
./mint.sh Godzilla $1
