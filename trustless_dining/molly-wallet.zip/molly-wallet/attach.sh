#!/bin/bash
docker exec -ti clevis bash
